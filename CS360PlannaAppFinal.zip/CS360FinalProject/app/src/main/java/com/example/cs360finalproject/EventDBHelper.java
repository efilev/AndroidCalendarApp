package com.example.cs360finalproject;

import static com.example.cs360finalproject.Event.eventsList;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;


public class EventDBHelper extends SQLiteOpenHelper  {

    private static EventDBHelper eventDBHelper;

    public static final String DBNAME = "eventsDB";
    // Change db version when updating DB Helper
    public static final int DB_VERSION = 4;
    public static final String TABLE_NAME = "events";
    private static final String COUNTER = "Counter";

    public static final String ID_FIELD = "id";
    public static final String NAME_FIELD = "name";
    public static final String DATE_FIELD = "date";
    public static final String TIME_FIELD = "time";


    public EventDBHelper(Context context) {
        super(context, DBNAME, null, DB_VERSION);
    }

    public static EventDBHelper instanceOfDatabase(Context context) {
        if (eventDBHelper == null)
            eventDBHelper = new EventDBHelper(context);
        return eventDBHelper;
    }

    @Override
    public void onCreate(SQLiteDatabase myDB) {
        StringBuilder sql;
        sql = new StringBuilder()
                .append("CREATE TABLE ")
                .append(TABLE_NAME)
                .append("(")
                .append(COUNTER)
                .append(" INTEGER PRIMARY KEY AUTOINCREMENT, ")
                .append(ID_FIELD)
                .append(" INT, ")
                .append(NAME_FIELD)
                .append(" TEXT, ")
                .append(DATE_FIELD)
                .append(" TEXT, ")
                .append(TIME_FIELD)
                .append(" TEXT)");
        myDB.execSQL(sql.toString());
    }

    @Override
    public void onUpgrade(SQLiteDatabase myDB, int oldVersion, int newVersion) {
    }

    // Create event
    public boolean addEvent(Event event) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(ID_FIELD, event.getId());
        values.put(NAME_FIELD, event.getName());
        values.put(DATE_FIELD, event.getDate().toString());
        values.put(TIME_FIELD, event.getTime().toString());

        long result = db.insert(TABLE_NAME, null, values);
        if(result==-1) return false;
        else
            return true;
    }

    // Read event
    public Cursor getAllEvents() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(
                TABLE_NAME,
                null,
                null,
                null,
                null,
                null,
                null
        );

        while (cursor.moveToNext()) {
        }

        cursor.close();
        return cursor;
    }

    // Update event
    public boolean updateEvent(Event event) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(ID_FIELD, event.getId());
        values.put(NAME_FIELD, event.getName());
        values.put(DATE_FIELD, event.getDate().toString());
        values.put(TIME_FIELD, event.getTime().toString());

        int result = db.update(TABLE_NAME, values, ID_FIELD + " =? ", new String[]{String.valueOf(event.getId())});
        return result > 0;
    }

    // Delete event
    public boolean deleteEvent(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        long result = db.delete(TABLE_NAME, "= ?", new String[]{String.valueOf(id)});
        return result > 0;
    }


}
