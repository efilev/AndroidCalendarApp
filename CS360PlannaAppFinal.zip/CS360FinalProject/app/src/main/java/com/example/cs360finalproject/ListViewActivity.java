package com.example.cs360finalproject;


import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;


public class ListViewActivity extends AppCompatActivity {

    private ListView eventListView;
    EventDBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_view);
        loadFromDBToMemory();
        setEventAdapter();

        eventListView = findViewById(R.id.eventListView);
        //db = new EventDBHelper(ListViewActivity.this);

        /*eventListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int item, long l) {
                new AlertDialog.Builder(ListViewActivity.this)
                        .setTitle("Delete item?")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Event.eventsList.remove(item);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                            }
                        }).create().show();
                return false;
            }
        }); */
    }

    private void loadFromDBToMemory() {
        //Cursor cursor = eventDBHelper.getAllEvents();
    }


    private void setEventAdapter() {
        EventAdapter eventAdapter = new EventAdapter(getApplicationContext(), Event.eventsList);
        eventListView.setAdapter(eventAdapter);
    }


    public void notifyListAction (View view) {
        startActivity(new Intent(ListViewActivity.this, NotifyActivity.class));
    }


}