package com.example.cs360finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class EventEditActivity extends AppCompatActivity
{
    private EditText eventNameET;
    private Button eventDateTV, eventTimeTV;

    private int selectedYear;
    private int selectedMonth;
    private int selectedDay;
    private int selectedHour;
    private int selectedMinute;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_edit);

        initWidgets();

        eventDateTV = findViewById(R.id.eventDateTV);
        eventTimeTV = findViewById(R.id.eventTimeTV);

        eventDateTV.setOnClickListener(view -> {
            openDateDialog();
        });

        eventTimeTV.setOnClickListener(view -> {
            openTimeDialog();
        });
    }



    private void initWidgets()
    {
        eventNameET = findViewById(R.id.eventNameET);
    }

    private void openDateDialog() {
        DatePickerDialog dialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                selectedYear = year;
                selectedMonth = month;
                selectedDay = day;
            }
        }, 2024, 0, 1);
        dialog.show();
    }

    private void openTimeDialog() {
        TimePickerDialog dialog = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker timePicker, int hours, int mins) {
;               selectedHour = hours;
                selectedMinute = mins;
            }
        }, 00, 00, true);
        dialog.show();
    }

    public void saveEventAction(View view)
    {
        EventDBHelper db = new EventDBHelper(EventEditActivity.this);
        int id = Event.eventsList.size();
        String eventName = eventNameET.getText().toString();
        LocalDate eventDate = LocalDate.of(selectedYear, selectedMonth + 1, selectedDay);
        LocalTime eventTime = LocalTime.of(selectedHour, selectedMinute);
        Event newEvent = new Event(id, eventName, eventDate, eventTime);
        Event.eventsList.add(newEvent);

        Boolean add = db.addEvent(newEvent);
        if (add == true) {
            Toast.makeText(EventEditActivity.this, "Added successfully", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(EventEditActivity.this, "Failed, please contact us", Toast.LENGTH_SHORT).show();
        }
        finish();
    }
}