package com.example.cs360finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {

    EditText inputUsername, inputPassword, repassword;
    Button btnRegister, btnSignin;
    UserDBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        inputUsername = (EditText) findViewById(R.id.inputUsername);
        inputPassword = (EditText) findViewById(R.id.inputPassword);
        repassword = (EditText) findViewById(R.id.inputRePassword);
        btnRegister = (Button) findViewById(R.id.btnRegister);
        btnSignin = (Button) findViewById(R.id.btnSignin);
        db = new UserDBHelper(this);

        btnRegister.setOnClickListener(view -> {
            String user = inputUsername.getText().toString().trim();
            String pass = inputPassword.getText().toString().trim();
            String repass = repassword.getText().toString().trim();

            if(user.equals("") || pass.equals("") || repass.equals("")) {
                Toast.makeText(RegisterActivity.this, "Please enter all the fields", Toast.LENGTH_SHORT).show();
            }
            else {
                if(pass.equals(repass)) {
                    Boolean checkuser = db.checkusername(user);
                    if(checkuser==false){
                        Boolean insert = db.insertData(user, pass);
                        if(insert==true){
                            Toast.makeText(RegisterActivity.this, "Registered successfully", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(),HomeActivity.class);
                            startActivity(intent);
                        }else{
                            Toast.makeText(RegisterActivity.this, "Registration failed", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else{
                        Toast.makeText(RegisterActivity.this, "User already exists! Please sign in", Toast.LENGTH_SHORT).show();
                    }
                }else{
                    Toast.makeText(RegisterActivity.this, "Passwords not matching", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnSignin.setOnClickListener(view -> {
            Intent i = new Intent(RegisterActivity.this, LoginActivity.class);
            startActivity(i);
            this.finish();
        });
    }





    // Empty edittext after done inserting in database
    public void EmptyEditTextAfterDataInsert(){
        inputUsername.getText().clear();
        inputPassword.getText().clear();
    }

}